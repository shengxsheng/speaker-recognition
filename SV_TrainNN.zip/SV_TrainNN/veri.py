import random
import shutil 
import os
import gc

print('make veriTXT.....')

data_folder = "/home/liuchenyan/corpus/Voxceleb/" #Voxceleb_all(7245語者語料)

new_spk1 = "TXTfile/4set/spk1.txt"
new_spk2 = "TXTfile/4set/spk2.txt"
new_spk3 = "TXTfile/4set/spk3.txt"
new_spk_o = "TXTfile/4set/others.txt"
s_file1 = open(new_spk1, "r")
s_file2 = open(new_spk2, "r")
s_file3 = open(new_spk3, "r")
s_file_o = open(new_spk_o, "r")

trainSet1 = "TXTfile/trainset/spk1.txt"
trainSet2 = "TXTfile/trainset/spk2.txt"
trainSet3 = "TXTfile/trainset/spk3.txt"
trainSet_o = "TXTfile/trainset/others.txt"
t_file1 = open(trainSet1, "w")
t_file2 = open(trainSet2, "w")
t_file3 = open(trainSet3, "w")
t_file_o = open(trainSet_o, "w")

valSet1 = "TXTfile/valset/spk1.txt"
valSet2 = "TXTfile/valset/spk2.txt"
valSet3 = "TXTfile/valset/spk3.txt"
valSet_o = "TXTfile/valset/others.txt"
v_file1 = open(valSet1, "w")
v_file2 = open(valSet2, "w")
v_file3 = open(valSet3, "w")
v_file_o = open(valSet_o, "w")

num = 0
for line in s_file1:
    num = num + 1
    if num%20 == 0:
        v_file1.write("%s"%line)
    else:
        t_file1.write("%s"%line)
s_file1.close()
t_file1.close()
v_file1.close()
num = 0
for line in s_file2:
    num = num + 1
    if num%20 == 0:
        v_file2.write("%s"%line)
    else:
        t_file2.write("%s"%line)
s_file2.close()
t_file2.close()
v_file2.close()
num = 0
for line in s_file3:
    num = num + 1
    if num%20 == 0:
        v_file3.write("%s"%line)
        t_file3.write("%s"%line)
s_file3.close()
t_file3.close()
v_file3.close()
num = 0
for line in s_file_o:
    num = num + 1
    if num%20 == 0:
        v_file_o.write("%s"%line)
    else:
        t_file_o.write("%s"%line)
s_file_o.close()
t_file_o.close()
v_file_o.close()
'''
num = 0
for line in s_file1:
    num = num + 1
    if num%20 == 0:
        v_file1.write("%s.wav\n" % line)
    else:
        t_file1.write("%s.wav\n" % line)
s_file1.close()
t_file1.close()
v_file1.close()
num = 0
for line in s_file2:
    num = num + 1
    if num%20 == 0:
        v_file2.write("%s.wav\n" % line)
    else:
        t_file2.write("%s.wav\n" % line)
s_file2.close()
t_file2.close()
v_file2.close()
num = 0
for line in s_file3:
    num = num + 1
    if num%20 == 0:
        v_file3.write("%s.wav\n" % line)
    else:
        t_file3.write("%s.wav\n" % line)
s_file3.close()
t_file3.close()
v_file3.close()
num = 0
for line in s_file_o:
    num = num + 1
    if num%20 == 0:
        v_file_o.write("%s.wav\n" % line)
    else:
        t_file_o.write("%s.wav\n" % line)
s_file_o.close()
t_file_o.close()
v_file_o.close()
'''
print('make veriTXT.....')
# enroll TXT
index_people = 0

n_1 = []
n_2 = []
n_3 = []

all_files1 = os.listdir("Wavfile/enrollWav/wav/id00001")
all_files2 = os.listdir("Wavfile/enrollWav/wav/id00002")
all_files3 = os.listdir("Wavfile/enrollWav/wav/id00003")

for file1 in all_files1:
    file1_1 = os.listdir("Wavfile/enrollWav/wav/id00001/"+file1)
    for file1_2 in file1_1:
        enrol_wav = ("id00001/%s/%s" %(file1,file1_2))
        n_1.append(enrol_wav)
for file2 in all_files2:
    file2_1 = os.listdir("Wavfile/enrollWav/wav/id00002/"+file2)
    for file2_2 in file2_1:
        enrol_wav = ("id00002/%s/%s" %(file2,file2_2))
        n_2.append(enrol_wav)
for file3 in all_files3:
    file3_1 = os.listdir("Wavfile/enrollWav/wav/id00003/"+file3)
    for file3_2 in file3_1:
        enrol_wav = ("id00003/%s/%s" %(file3,file3_2))
        n_3.append(enrol_wav)

# veriTXT destination
veri = "TXTfile/veri.txt"

valspk1 = []
valspk2 = []
valspk3 = []
valothers = []

with open(valSet1) as e:
    for line in e:
        valspk1.append(line.rstrip('\n'))
with open(valSet2) as e:
    for line in e:
        valspk2.append(line.rstrip('\n'))
with open(valSet3) as e:
    for line in e:
        valspk3.append(line.rstrip('\n'))
with open(valSet_o) as e:
    for line in e:
        valothers.append(line.rstrip('\n'))


spk1_others = []
spk1_others.extend(valspk2)
spk1_others.extend(valspk3)
spk1_others.extend(valothers)
random.shuffle(spk1_others)
spk2_others = []
spk2_others.extend(valspk1)
spk2_others.extend(valspk3)
spk2_others.extend(valothers)
random.shuffle(spk2_others)
spk3_others = []
spk3_others.extend(valspk1)
spk3_others.extend(valspk2)
spk3_others.extend(valothers)
random.shuffle(spk3_others)

spk1_1 =[ ]
spk1_1.extend(n_2)
spk1_1.extend(n_3)

spk2_1 =[ ]
spk2_1.extend(n_1)
spk2_1.extend(n_3)

spk3_1 =[ ]
spk3_1.extend(n_2)
spk3_1.extend(n_1)

veri_file = open(veri, "w")

# SPK1
for x in range(len(valspk1)):
    index = x % 5
    veri_file.write("1 %s %s\n" %(n_1[index], valspk1[x]))
for x in range(len(valspk1)):
    index = x % 5
    if x < len(spk1_1):
        veri_file.write("0 %s %s\n" %(n_1[index], spk1_1[x]))
    else:
        veri_file.write("0 %s %s\n" %(n_1[index], spk1_others[x]))
# SPK2
for x in range(len(valspk2)):
    index = x % 5
    veri_file.write("1 %s %s\n" %(n_2[index], valspk2[x]))
for x in range(len(valspk2)):
    index = x % 5
    if x < len(spk2_1):
        veri_file.write("0 %s %s\n" %(n_2[index], spk2_1[x]))
    else:
        veri_file.write("0 %s %s\n" %(n_2[index], spk2_others[x]))
# SPK3
for x in range(len(valspk3)):
    index = x % 5
    veri_file.write("1 %s %s\n" %(n_3[index], valspk3[x]))
for x in range(len(valspk3)):
    index = x % 5
    if x < len(spk3_1):
        veri_file.write("0 %s %s\n" %(n_3[index], spk3_1[x]))
    else:
        veri_file.write("0 %s %s\n" %(n_3[index], spk3_others[x]))



veri_file.close()


print('veri_file done')

print('copy new wav to distination.....')
all_files = os.listdir("TXTfile/trainset")

for file in all_files:
    with open('TXTfile/trainset/' + file,'r') as r:
        lines=r.readlines()
    for l in lines:
        src = data_folder+"wav/"+l.rstrip("\n")
        destination_folder = "Wavfile/newWav/wav/"+file.strip('.txt')+'/'+l.split('/')[1]+"/"

        os.makedirs(os.path.dirname(destination_folder), exist_ok=True)
   
        shutil.copy2(src,destination_folder)


with open('TXTfile/veri.txt','r') as r:
   lines=r.readlines()

for l in lines:
   src= data_folder+"wav/"+l.split(' ')[2].rstrip('\n')
   destination_folder = "Wavfile/newWav/wav/"+l.split(' ')[2][0:20]

   os.makedirs(os.path.dirname(destination_folder), exist_ok=True)
   
   shutil.copy2(src,destination_folder)

gc.collect()
print("copy done :)")